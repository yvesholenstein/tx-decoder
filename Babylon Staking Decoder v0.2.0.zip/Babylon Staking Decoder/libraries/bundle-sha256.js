// Bundle entry point for @noble/hashes
import { sha256 } from '@noble/hashes/sha256';
window.nobleSha256 = { sha256 };
export { sha256 };
