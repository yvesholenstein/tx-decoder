import { TinySecp256k1Interface } from './types';
export declare function initEccLib(eccLib: TinySecp256k1Interface | undefined): void;
export declare function getEccLib(): TinySecp256k1Interface;
