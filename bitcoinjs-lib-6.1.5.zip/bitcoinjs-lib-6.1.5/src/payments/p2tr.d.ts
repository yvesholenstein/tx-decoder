import { Payment, PaymentOpts } from './index';
export declare function p2tr(a: Payment, opts?: PaymentOpts): Payment;
