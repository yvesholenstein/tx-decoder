// Load saved settings and API key
function loadApiKey() {
    const savedKey = localStorage.getItem('etherscanApiKey');

    if (savedKey) {
        document.getElementById('api-key').value = savedKey;
        document.getElementById('api-key-status').textContent = '✓ Etherscan API key loaded (works for all chains)';
        document.getElementById('api-key-status').style.color = '#28a745';
    } else {
        document.getElementById('api-key-status').textContent = '';
    }

    const darkMode = localStorage.getItem('darkMode');
    if (darkMode === 'true') {
        document.body.classList.add('dark-mode');
    }

    const savedSettings = localStorage.getItem('decoderSettings');
    if (savedSettings) {
        settings = JSON.parse(savedSettings);
        document.getElementById('format-amounts').checked = settings.formatAmounts;
        document.getElementById('show-usd').checked = settings.showUSD;
    }
}

// Save settings
function saveSettings() {
    settings.formatAmounts = document.getElementById('format-amounts').checked;
    settings.showUSD = document.getElementById('show-usd').checked;
    localStorage.setItem('decoderSettings', JSON.stringify(settings));
}

// Save API key
function saveApiKey(apiKey) {
    localStorage.setItem('etherscanApiKey', apiKey);
    document.getElementById('api-key-status').textContent = '✓ Etherscan API key saved (works for all chains)';
    document.getElementById('api-key-status').style.color = '#28a745';
}

// Open settings modal
function openSettings() {
    document.getElementById('settings-modal').classList.add('active');
}

// Close settings modal
function closeSettings() {
    document.getElementById('settings-modal').classList.remove('active');
}

// Toggle dark mode
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDark);
}

// Switch between manual and auto modes
function switchMode(mode) {
    document.querySelectorAll('.mode-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.input-section').forEach(section => section.classList.remove('active'));
    
    if (mode === 'manual') {
        document.querySelector('.mode-btn:first-child').classList.add('active');
        document.getElementById('manual-mode').classList.add('active');
    } else {
        document.querySelector('.mode-btn:last-child').classList.add('active');
        document.getElementById('auto-mode').classList.add('active');
    }
    
    hideOutput();
}

// Handle chain selection change
function onChainChange() {
    currentChain = document.getElementById('chain-select').value;
    updateExplorerHint();
    loadApiKey();
    hideOutput();
    
    // Clear previous results
    document.getElementById('output-content').innerHTML = '';
}

// Update explorer hint text
function updateExplorerHint() {
    document.getElementById('explorer-hint').textContent = 'Etherscan API key - works for all supported chains - saved locally';
}

// Show error message
function showError(message) {
    const html = `<div class="error-message">${message}</div>`;
    document.getElementById('output-content').innerHTML = html;
    showOutput();
}

// Show output section
function showOutput() {
    document.getElementById('output').classList.add('active');
}

// Hide output section
function hideOutput() {
    document.getElementById('output').classList.remove('active');
}