// Suppress console warnings
(function() {
    const originalWarn = console.warn;
    console.warn = function(...args) {
        const message = args.join(' ');
        if (message.includes('initEternlDomAPI')) return;
        originalWarn.apply(console, args);
    };
})();

// Format number with thousands separators (using apostrophe)
function formatWithCommas(numStr) {
    try {
        // Handle decimal numbers
        const parts = numStr.split('.');
        const integerPart = parts[0];
        const decimalPart = parts[1];

        // Add apostrophes to integer part as thousands separator
        const withSeparators = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, "'");

        // Return with decimal part if it exists
        return decimalPart !== undefined ? `${withSeparators}.${decimalPart}` : withSeparators;
    } catch (e) {
        return numStr;
    }
}

// Get current chain configuration
function getCurrentChain() {
    return CHAIN_CONFIG[currentChain];
}

// Get token info for current chain
function getTokenInfo(address) {
    const normalized = address.toLowerCase();
    const chainTokens = TOKEN_DATABASE[currentChain] || {};
    return chainTokens[normalized] || null;
}

// Fetch token decimals from blockchain
async function fetchTokenDecimals(address) {
    try {
        const chain = getCurrentChain();
        const provider = new ethers.providers.JsonRpcProvider(chain.rpcUrl);
        const contract = new ethers.Contract(
            address,
            ['function decimals() view returns (uint8)', 'function symbol() view returns (string)'],
            provider
        );

        // Set a timeout for RPC calls (5 seconds)
        const timeout = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('RPC timeout')), 5000)
        );

        const [decimals, symbol] = await Promise.race([
            Promise.all([
                contract.decimals(),
                contract.symbol().catch(() => 'TOKEN')
            ]),
            timeout
        ]);

        return { decimals, symbol };
    } catch (error) {
        console.warn(`Could not fetch token info for ${address}:`, error.message);
        // Return null so transaction can still be decoded without token formatting
        return null;
    }
}

// Fetch token price from CoinGecko
async function fetchTokenPrice(symbol) {
    if (priceCache[symbol] && Date.now() - priceCache[symbol].timestamp < 300000) {
        return priceCache[symbol].price;
    }

    try {
        const coinIds = {
            'ETH': 'ethereum',
            'WETH': 'ethereum',
            'USDC': 'usd-coin',
            'USDT': 'tether',
            'WBTC': 'wrapped-bitcoin',
            'DAI': 'dai',
            'BNB': 'binancecoin',
            'UNI': 'uniswap',
            'LINK': 'chainlink',
            'AAVE': 'aave',
            'POL': 'polygon-ecosystem-token',
            'MATIC': 'matic-network',
            'AVAX': 'avalanche-2',
            'STETH': 'lido-staked-ether',
            'LSETH': 'liquid-staked-ethereum',
            'BABY': 'babyswap'
        };

        const coinId = coinIds[symbol];
        if (!coinId) return null;

        const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd`);
        const data = await response.json();
        
        const price = data[coinId]?.usd;
        if (price) {
            priceCache[symbol] = { price, timestamp: Date.now() };
        }
        
        return price;
    } catch (error) {
        console.error('Error fetching price:', error);
        return null;
    }
}

// Format token amount
async function formatTokenAmount(value, tokenAddress) {
    if (!settings.formatAmounts) return null;

    let tokenInfo = getTokenInfo(tokenAddress);
    
    if (!tokenInfo && ethers.utils.isAddress(tokenAddress)) {
        const fetched = await fetchTokenDecimals(tokenAddress);
        if (fetched) {
            tokenInfo = { symbol: fetched.symbol, decimals: fetched.decimals };
        }
    }

    if (!tokenInfo) return null;

    const formatted = ethers.utils.formatUnits(value, tokenInfo.decimals);
    let result = `${formatted} ${tokenInfo.symbol}`;

    if (settings.showUSD) {
        const price = await fetchTokenPrice(tokenInfo.symbol);
        if (price) {
            const usdValue = (parseFloat(formatted) * price).toFixed(2);
            result += ` ($${usdValue})`;
        }
    }

    return result;
}

// Try to decode with common ABIs
function tryCommonAbis(txData) {
    for (const [name, abi] of Object.entries(COMMON_ABIS)) {
        try {
            const iface = new ethers.utils.Interface(abi);
            const decoded = iface.parseTransaction({ data: txData });
            if (decoded) {
                return { abi, protocol: name };
            }
        } catch (e) {
            continue;
        }
    }
    return null;
}

// Fetch ABI from unified Etherscan v2 API
async function fetchAbiFromEtherscan(address, apiKey) {
    const chain = getCurrentChain();

    try {
        const url = `${ETHERSCAN_V2_API}?chainid=${chain.chainId}&module=contract&action=getabi&address=${address}&apikey=${apiKey}`;
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error('CORS_BLOCKED');
        }

        const data = await response.json();

        if (data.status !== '1') {
            if (data.result && (data.result.includes('not verified') || data.result.includes('Contract source code not verified'))) {
                throw new Error('CONTRACT_NOT_VERIFIED');
            }
            throw new Error(data.result || 'Unknown error from Etherscan API');
        }

        return JSON.parse(data.result);
    } catch (directError) {
        if (directError.message === 'CONTRACT_NOT_VERIFIED') {
            throw directError;
        }

        try {
            const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(`${ETHERSCAN_V2_API}?chainid=${chain.chainId}&module=contract&action=getabi&address=${address}&apikey=${apiKey}`)}`;
            const response = await fetch(proxyUrl);
            const data = await response.json();

            if (data.status !== '1') {
                if (data.result && (data.result.includes('not verified') || data.result.includes('Contract source code not verified'))) {
                    throw new Error('CONTRACT_NOT_VERIFIED');
                }
                throw new Error(data.result || 'Unknown error from Etherscan API');
            }

            return JSON.parse(data.result);
        } catch (proxyError) {
            if (proxyError.message === 'CONTRACT_NOT_VERIFIED') {
                throw proxyError;
            }
            throw new Error('CORS_BLOCKED');
        }
    }
}

// Decode transaction data
async function decodeTxData(txData, abi, protocol = null, contractAddress = null) {
    const iface = new ethers.utils.Interface(abi);
    const decoded = iface.parseTransaction({ data: txData });

    return {
        functionName: decoded.name,
        signature: decoded.signature,
        args: decoded.args,
        fragment: decoded.functionFragment,
        protocol: protocol,
        contractAddress: contractAddress,
        txData: txData  // Add raw transaction data
    };
}

// Decode specific Universal Router command inputs
function decodeCommandInput(commandCode, inputData) {
    if (!inputData) return null;

    try {
        const abiCoder = ethers.utils.defaultAbiCoder;

        switch (commandCode) {
            case '0x00': // V3_SWAP_EXACT_IN
                const v3SwapParams = abiCoder.decode(
                    ['address', 'uint256', 'uint256', 'bytes', 'bool'],
                    inputData
                );
                return {
                    recipient: v3SwapParams[0],
                    amountIn: v3SwapParams[1].toString(),
                    amountOutMin: v3SwapParams[2].toString(),
                    path: v3SwapParams[3],
                    payerIsUser: v3SwapParams[4]
                };

            case '0x08': // V2_SWAP_EXACT_IN
                const v2SwapParams = abiCoder.decode(
                    ['address', 'uint256', 'uint256', 'address[]', 'bool'],
                    inputData
                );
                return {
                    recipient: v2SwapParams[0],
                    amountIn: v2SwapParams[1].toString(),
                    amountOutMin: v2SwapParams[2].toString(),
                    path: v2SwapParams[3],
                    payerIsUser: v2SwapParams[4]
                };

            case '0x0a': // PERMIT2_PERMIT
                // PERMIT2_PERMIT has a complex nested structure with PermitSingle struct
                try {
                    const permitParams = abiCoder.decode(
                        ['tuple(tuple(address token, uint160 amount, uint48 expiration, uint48 nonce) details, address spender, uint256 sigDeadline)', 'bytes'],
                        inputData
                    );
                    const details = permitParams[0][0];
                    const spender = permitParams[0][1];
                    const sigDeadline = permitParams[0][2];
                    const signature = permitParams[1];

                    // Format date as ISO with 24h time
                    const expirationDate = new Date(details[2] * 1000);
                    const isoExpiration = expirationDate.toISOString().replace('T', ' ').slice(0, 19);

                    return {
                        token: details[0],
                        amount: details[1].toString(),
                        expiration: isoExpiration,
                        nonce: details[3].toString(),
                        spender: spender,
                        sigDeadline: sigDeadline.toString(),
                        signature: signature.slice(0, 20) + '...'
                    };
                } catch (e) {
                    // Fallback to simpler decoding if nested structure fails
                    console.warn('PERMIT2_PERMIT nested decode failed, trying flat:', e);
                    const flatParams = abiCoder.decode(
                        ['address', 'uint160', 'uint48', 'uint48', 'address', 'uint256'],
                        inputData
                    );

                    // Format date as ISO with 24h time
                    const expirationDate = new Date(flatParams[2] * 1000);
                    const isoExpiration = expirationDate.toISOString().replace('T', ' ').slice(0, 19);

                    return {
                        token: flatParams[0],
                        amount: flatParams[1].toString(),
                        expiration: isoExpiration,
                        nonce: flatParams[3].toString(),
                        spender: flatParams[4],
                        sigDeadline: flatParams[5].toString()
                    };
                }

            case '0x02': // PERMIT2_TRANSFER_FROM
                const transferParams = abiCoder.decode(
                    ['address', 'address', 'uint160'],
                    inputData
                );
                return {
                    token: transferParams[0],
                    recipient: transferParams[1],
                    amount: transferParams[2].toString()
                };

            case '0x04': // SWEEP
                const sweepParams = abiCoder.decode(
                    ['address', 'address', 'uint256'],
                    inputData
                );
                return {
                    token: sweepParams[0],
                    recipient: sweepParams[1],
                    amountMin: sweepParams[2].toString()
                };

            case '0x0b': // WRAP_ETH
                const wrapParams = abiCoder.decode(
                    ['address', 'uint256'],
                    inputData
                );
                return {
                    recipient: wrapParams[0],
                    amountMin: wrapParams[1].toString()
                };

            case '0x0c': // UNWRAP_WETH
                const unwrapParams = abiCoder.decode(
                    ['address', 'uint256'],
                    inputData
                );
                return {
                    recipient: unwrapParams[0],
                    amountMin: unwrapParams[1].toString()
                };

            case '0x06': // PAY_PORTION
                const payPortionParams = abiCoder.decode(
                    ['address', 'address', 'uint256'],
                    inputData
                );
                return {
                    token: payPortionParams[0],
                    recipient: payPortionParams[1],
                    bips: payPortionParams[2].toString()
                };

            case '0x10': // V4_SWAP
                const v4SwapParams = abiCoder.decode(
                    ['address', 'address', 'uint256'],
                    inputData
                );
                return {
                    poolManager: v4SwapParams[0],
                    recipient: v4SwapParams[1],
                    actions: v4SwapParams[2].toString()
                };

            default:
                return { raw: inputData };
        }
    } catch (error) {
        console.error(`Error decoding command ${commandCode}:`, error);
        return { raw: inputData, error: error.message };
    }
}

// Decode Uniswap Universal Router execute command
function decodeUniversalRouterCommands(commandsBytes, inputs) {
    const commands = [];
    const commandsData = commandsBytes.startsWith('0x') ? commandsBytes.slice(2) : commandsBytes;

    for (let i = 0; i < commandsData.length; i += 2) {
        const commandByte = '0x' + commandsData.slice(i, i + 2);
        const commandName = UNISWAP_COMMANDS[commandByte] || `UNKNOWN(${commandByte})`;
        const commandIndex = i / 2;

        const inputData = inputs && inputs[commandIndex] ? inputs[commandIndex] : null;
        const decodedInput = inputData ? decodeCommandInput(commandByte, inputData) : null;

        commands.push({
            index: commandIndex,
            code: commandByte,
            name: commandName,
            input: inputData,
            decoded: decodedInput
        });
    }

    return commands;
}

// Assess risk level with improved logic for approvals
function assessRisk(functionName, params, protocol) {
    const highRiskFunctions = ['setApprovalForAll', 'transferOwnership', 'delegatecall'];
    const mediumRiskFunctions = ['transfer', 'transferFrom', 'withdraw', 'borrow'];

    const lowerName = functionName.toLowerCase();

    // Special handling for Uniswap Universal Router execute
    if (lowerName === 'execute' && protocol === 'UniswapUniversalRouter') {
        return 'high'; // Execute function spends tokens/ETH
    }

    // Special handling for approve functions
    if (lowerName.includes('approve') && !lowerName.includes('setapprovalforall')) {
        // Check if there's an amount parameter
        if (params && params.length >= 2) {
            try {
                // Typically the second parameter is the amount
                const amount = ethers.BigNumber.from(params[1]);

                // Check if it's unlimited approval (max uint256 or very large numbers)
                const maxUint256 = ethers.constants.MaxUint256;
                const almostMax = ethers.BigNumber.from('0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff');

                // If amount is max uint256 or within 1% of it, it's unlimited
                if (amount.eq(maxUint256) || amount.gte(almostMax.mul(99).div(100))) {
                    return 'high'; // Unlimited approval
                } else {
                    return 'medium'; // Limited approval
                }
            } catch (e) {
                // If we can't parse the amount, default to high risk to be safe
                return 'high';
            }
        }
        return 'high'; // Default for approve if we can't determine
    }

    // Check other high risk functions
    if (highRiskFunctions.some(fn => lowerName.includes(fn.toLowerCase()))) {
        return 'high';
    }

    // Check medium risk functions
    if (mediumRiskFunctions.some(fn => lowerName.includes(fn.toLowerCase()))) {
        return 'medium';
    }

    return 'low';
}

// Detect if data is EIP-712 JSON structure
function isEIP712JSON(txData) {
    try {
        // Quick check before parsing
        if (!txData.trim().startsWith('{')) {
            return false;
        }

        const data = JSON.parse(txData);
        return !!(data.types && data.domain && data.primaryType && data.message);
    } catch (e) {
        return false;
    }
}

// Detect if data is EIP-712 encoded typed message (hex)
function isEIP712Data(txData) {
    // First check if it's JSON - if so, it's not hex-encoded EIP-712
    if (txData.trim().startsWith('{')) {
        return false;
    }

    // Remove 0x prefix if present
    const cleanData = txData.startsWith('0x') ? txData.slice(2) : txData;

    // EIP-712 encoded data is typically:
    // - Long (> 256 bytes typically)
    // - Contains multiple 32-byte chunks
    // - Can be parsed as valid ABI encoding

    if (cleanData.length < 512) {
        return false; // Too short to be a typical EIP-712 message
    }

    // Check if it's valid hex
    if (!/^[0-9a-fA-F]+$/.test(cleanData)) {
        return false;
    }

    // Length should be multiple of 64 (32 bytes in hex)
    if (cleanData.length % 64 !== 0) {
        return false;
    }

    // If it starts with a common function selector (4 bytes), it's likely a regular transaction
    // EIP-712 ABI-encoded messages typically start with full 32-byte values
    const potentialSelector = '0x' + cleanData.slice(0, 8);
    const commonSelectors = ['0x095ea7b3', '0xa9059cbb', '0x23b872dd', '0x18160ddd'];
    if (commonSelectors.includes(potentialSelector.toLowerCase())) {
        return false;
    }

    return true; // Possibly EIP-712 encoded data
}

// Encode and decode EIP-712 JSON structure
async function encodeAndDecodeEIP712JSON(jsonString) {
    try {
        const data = JSON.parse(jsonString);

        // Validate required fields
        if (!data.types || !data.domain || !data.primaryType || !data.message) {
            throw new Error('Invalid EIP-712 data structure. Must include types, domain, primaryType, and message.');
        }

        const domain = data.domain;
        const types = {};

        // Copy types excluding EIP712Domain
        for (const [key, value] of Object.entries(data.types)) {
            if (key !== 'EIP712Domain') {
                types[key] = value;
            }
        }

        // Get the primary type
        const primaryType = data.primaryType;
        const message = data.message;

        // Step 1: Compute type hash
        const encoder = ethers.utils._TypedDataEncoder.from(types);
        const typeString = encoder.encodeType(primaryType);
        const typeHash = ethers.utils.keccak256(ethers.utils.toUtf8Bytes(typeString));

        // Step 2: ABI-encode the message
        const messageTypes = types[primaryType].map(field => field.type);
        const messageValues = types[primaryType].map(field => message[field.name]);
        const encodedMessage = ethers.utils.defaultAbiCoder.encode(messageTypes, messageValues);

        // Step 3: Compute struct hash (typeHash + encodedMessage)
        const structHashData = ethers.utils.concat([typeHash, encodedMessage]);
        const structHash = ethers.utils.keccak256(structHashData);

        // Step 4: Compute domain separator
        const domainHash = ethers.utils._TypedDataEncoder.hashDomain(domain);

        // Final: Compute EIP-712 hash
        const finalHashData = ethers.utils.concat([
            ethers.utils.toUtf8Bytes('\x19\x01'),
            domainHash,
            structHash
        ]);
        const finalHash = ethers.utils.keccak256(finalHashData);

        // Parse encoded message into chunks for display
        const chunks = [];
        const cleanData = encodedMessage.slice(2);
        for (let i = 0; i < cleanData.length; i += 64) {
            chunks.push('0x' + cleanData.slice(i, i + 64));
        }

        const interpretations = [];
        chunks.forEach((chunk, index) => {
            const interpretation = { index, raw: chunk, possibleTypes: [] };

            // Check for addresses
            if (chunk.slice(0, 26) === '0x000000000000000000000000') {
                const addr = '0x' + chunk.slice(26);
                interpretation.possibleTypes.push({ type: 'address', value: addr });
            }

            // Check for uint256
            try {
                const bigNum = ethers.BigNumber.from(chunk);
                interpretation.possibleTypes.push({ type: 'uint256', value: bigNum.toString() });
            } catch (e) {
                // Not a valid number
            }

            interpretation.possibleTypes.push({ type: 'bytes32', value: chunk });
            interpretations.push(interpretation);
        });

        return {
            isEIP712: true,
            isFromJSON: true,
            typeHash: typeHash,
            rawData: encodedMessage,
            structHash: structHash,
            domainSeparator: domainHash,
            finalHash: finalHash,
            interpretations: interpretations,
            primaryType: primaryType,
            domain: domain
        };
    } catch (error) {
        throw new Error('Failed to process EIP-712 JSON: ' + error.message);
    }
}

// Decode EIP-712 encoded message (hex only)
async function decodeEIP712(txData) {
    try {
        const cleanData = txData.startsWith('0x') ? txData : '0x' + txData;

        // Parse the data into 32-byte chunks
        const chunks = [];
        const data = cleanData.slice(2);
        for (let i = 0; i < data.length; i += 64) {
            chunks.push('0x' + data.slice(i, i + 64));
        }

        // Try to identify common EIP-712 structures
        // Common patterns: Order, Permit, Message, etc.

        const result = {
            isEIP712: true,
            rawData: cleanData,
            chunks: chunks,
            interpretations: []
        };

        // Analyze chunks for common patterns
        chunks.forEach((chunk, index) => {
            const interpretation = { index, raw: chunk, possibleTypes: [] };

            // Check for addresses
            if (chunk.slice(0, 26) === '0x000000000000000000000000') {
                const addr = '0x' + chunk.slice(26);
                interpretation.possibleTypes.push({ type: 'address', value: addr });
            }

            // Check for uint256
            try {
                const bigNum = ethers.BigNumber.from(chunk);
                interpretation.possibleTypes.push({ type: 'uint256', value: bigNum.toString() });
            } catch (e) {
                // Not a valid number
            }

            // Check for bytes32/hash (could be type hash, domain separator, etc.)
            interpretation.possibleTypes.push({ type: 'bytes32', value: chunk });

            result.interpretations.push(interpretation);
        });

        // Try to compute potential EIP-712 hashes
        try {
            // Attempt to identify type hash (usually first 32 bytes or early in structure)
            const potentialTypeHash = chunks[0];

            // Compute struct hash (keccak256 of all the data)
            const structHash = ethers.utils.keccak256(cleanData);

            result.potentialTypeHash = potentialTypeHash;
            result.structHash = structHash;

            // Note: Without the actual EIP-712 typed data JSON, we can only show the encoded form
            result.note = 'This appears to be ABI-encoded data, possibly from an EIP-712 typed message. ' +
                         'The original typed data structure is needed for complete decoding.';
        } catch (e) {
            result.error = e.message;
        }

        return result;
    } catch (error) {
        throw new Error('Failed to decode as EIP-712: ' + error.message);
    }
}

// Manual decode without ABI
function manualDecode(txData) {
    const selector = txData.slice(0, 10);
    const params = txData.slice(10);

    const chunks = [];
    for (let i = 0; i < params.length; i += 64) {
        chunks.push('0x' + params.slice(i, i + 64));
    }

    const decoded = {
        selector: selector,
        rawParams: chunks,
        interpretations: [],
        txData: txData  // Add raw transaction data
    };

    chunks.forEach((chunk, index) => {
        const interpretation = { index, raw: chunk, possibleTypes: [] };

        // Check if it could be an address
        if (chunk.slice(0, 26) === '0x000000000000000000000000') {
            const addr = '0x' + chunk.slice(26);
            interpretation.possibleTypes.push({ type: 'address', value: addr });

            const tokenInfo = getTokenInfo(addr);
            if (tokenInfo) {
                interpretation.possibleTypes.push({
                    type: 'token_address',
                    value: addr,
                    symbol: tokenInfo.symbol,
                    decimals: tokenInfo.decimals
                });
            }
        }

        // Check if it could be a uint256
        try {
            const bigNum = ethers.BigNumber.from(chunk);
            interpretation.possibleTypes.push({ type: 'uint256', value: bigNum.toString() });

            if (bigNum.gt(0) && bigNum.lt(ethers.BigNumber.from('1000000000000000000000000'))) {
                [18, 6, 8].forEach(decimals => {
                    const formatted = ethers.utils.formatUnits(bigNum, decimals);
                    if (parseFloat(formatted) > 0 && parseFloat(formatted) < 1000000000) {
                        interpretation.possibleTypes.push({
                            type: `amount_${decimals}decimals`,
                            value: formatted
                        });
                    }
                });
            }
        } catch (e) {
            // Not a valid number
        }

        interpretation.possibleTypes.push({ type: 'bytes32', value: chunk });

        decoded.interpretations.push(interpretation);
    });

    return decoded;
}

// AI assessment of transaction
function assessTransaction(decoded) {
    const assessment = {
        likelyFunction: 'Unknown',
        confidence: 'low',
        description: '',
        parameters: []
    };
    
    const params = decoded.interpretations;
    
    const hasTokenAddress = params.some(p => p.possibleTypes.some(t => t.type === 'token_address'));
    const hasMultipleAmounts = params.filter(p => p.possibleTypes.some(t => t.type.startsWith('amount_'))).length >= 2;
    const hasBytes32 = params.some(p => p.possibleTypes.some(t => t.type === 'bytes32'));
    
    if (hasTokenAddress && hasMultipleAmounts) {
        assessment.likelyFunction = 'Bridge/Transfer Token';
        assessment.confidence = 'medium';
        
        params.forEach((param, index) => {
            const tokenType = param.possibleTypes.find(t => t.type === 'token_address');
            const addressType = param.possibleTypes.find(t => t.type === 'address');
            const amountTypes = param.possibleTypes.filter(t => t.type.startsWith('amount_'));
            const uint256Type = param.possibleTypes.find(t => t.type === 'uint256');
            
            if (tokenType) {
                assessment.parameters.push({
                    index,
                    name: 'token',
                    type: 'address',
                    description: `Token to transfer: ${tokenType.symbol}`,
                    value: tokenType.value
                });
            } else if (amountTypes.length > 0) {
                const rawValue = ethers.BigNumber.from(param.raw);
                
                const tokenParam = params.find(p => p.possibleTypes.some(t => t.type === 'token_address'));
                if (tokenParam) {
                    const token = tokenParam.possibleTypes.find(t => t.type === 'token_address');
                    const formatted = ethers.utils.formatUnits(rawValue, token.decimals);
                    
                    const isFee = parseFloat(formatted) < 0.1 && index < params.length - 1;
                    
                    assessment.parameters.push({
                        index,
                        name: isFee ? 'destinationFee' : 'amount',
                        type: `uint128 or uint256`,
                        description: isFee 
                            ? `Destination chain fee: ${formatted} ${token.symbol}` 
                            : `Transfer amount: ${formatted} ${token.symbol}`,
                        value: rawValue.toString(),
                        formatted: `${formatted} ${token.symbol}`
                    });
                }
            } else if (hasBytes32 && param.possibleTypes.some(t => t.type === 'bytes32')) {
                assessment.parameters.push({
                    index,
                    name: 'destinationAddress',
                    type: 'bytes32',
                    description: 'Destination address (possibly on another chain)',
                    value: param.raw
                });
            } else if (addressType && !tokenType) {
                assessment.parameters.push({
                    index,
                    name: 'recipient',
                    type: 'address',
                    description: 'Recipient address',
                    value: addressType.value
                });
            } else if (uint256Type) {
                const num = ethers.BigNumber.from(param.raw);
                if (num.eq(0) || num.eq(1)) {
                    assessment.parameters.push({
                        index,
                        name: 'flag',
                        type: 'bool or uint8',
                        description: `Boolean flag: ${num.eq(1) ? 'true' : 'false'}`,
                        value: num.toString()
                    });
                } else {
                    assessment.parameters.push({
                        index,
                        name: `param${index}`,
                        type: 'uint256',
                        description: `Numeric parameter: ${num.toString()}`,
                        value: num.toString()
                    });
                }
            }
        });
        
        if (hasBytes32) {
            assessment.description = 'This appears to be a cross-chain bridge transaction. It transfers tokens from this chain to another blockchain.';
        } else {
            assessment.description = 'This appears to be a token transfer or swap with multiple amounts (possibly including fees).';
        }
        
        const paramTypes = assessment.parameters.map(p => `${p.type} ${p.name}`).join(', ');
        assessment.likelyFunction = `sendToken(${paramTypes})`;
        assessment.confidence = 'medium-high';
        
    } else if (hasTokenAddress && params.length === 2) {
        assessment.likelyFunction = 'approve(address spender, uint256 amount)';
        assessment.confidence = 'high';
        assessment.description = 'Standard ERC20 approval to allow another address to spend tokens.';
        
    } else {
        assessment.description = 'Unable to determine specific function pattern. See parameter interpretations below.';
    }
    
    return assessment;
}

// Decode manual mode
async function decodeManual() {
    const txData = document.getElementById('manual-tx-data').value.trim();
    const abiJson = document.getElementById('manual-abi').value.trim();

    if (!txData) {
        showError('Please provide transaction data');
        return;
    }

    // Check if data is EIP-712 JSON structure (typed data)
    const isJSON = isEIP712JSON(txData);
    console.log('Is EIP-712 JSON?', isJSON);

    if (isJSON) {
        console.log('Processing as EIP-712 JSON');
        try {
            const decoded = await encodeAndDecodeEIP712JSON(txData);
            displayEIP712Decoded(decoded);
            return;
        } catch (error) {
            console.error('EIP-712 JSON processing error:', error);
            showError('Failed to process EIP-712 JSON: ' + error.message);
            return;
        }
    }

    // Check if data is EIP-712 encoded hex
    const isHex = isEIP712Data(txData);
    console.log('Is EIP-712 Hex?', isHex);

    if (isHex) {
        console.log('Processing as EIP-712 Hex');
        try {
            const decoded = await decodeEIP712(txData);
            displayEIP712Decoded(decoded);
            return;
        } catch (error) {
            // If EIP-712 decode fails, fall through to normal decoding
            console.error('EIP-712 hex decode failed:', error);
        }
    }

    console.log('Processing as regular transaction');

    if (!abiJson) {
        const decoded = manualDecode(txData);
        displayManualDecoded(decoded);
        return;
    }

    try {
        const abi = JSON.parse(abiJson);
        console.log('Parsed ABI:', abi);

        // Check if ABI only contains proxy functions (no regular functions)
        const functions = abi.filter(item => item.type === 'function');
        const hasFallbackOrReceive = abi.some(item => item.type === 'fallback' || item.type === 'receive');

        console.log('Functions in ABI:', functions.length);
        console.log('Has fallback/receive:', hasFallbackOrReceive);
        console.log('Should show proxy warning:', functions.length === 0 && hasFallbackOrReceive);

        // If there are no functions, or only constructor, and it has fallback/receive, it's likely a proxy
        if (functions.length === 0 && hasFallbackOrReceive) {
            console.log('Showing proxy warning');
            const decoded = manualDecode(txData);
            decoded.proxyWarning = '⚠️ Proxy Contract Detected: The ABI you provided appears to be for a proxy contract (only contains fallback/receive/events/constructor). To decode properly, you need the Implementation Contract ABI. Check the block explorer for "Read as Proxy" or "Implementation" to find the actual contract address, then use that ABI instead.';
            displayManualDecoded(decoded);
            return;
        }

        console.log('Attempting to decode with provided ABI');
        const decoded = await decodeTxData(txData, abi);
        displayDecoded(decoded);
    } catch (error) {
        console.log('Error in manual decode:', error);
        const commonResult = tryCommonAbis(txData);
        if (commonResult) {
            try {
                const decoded = await decodeTxData(txData, commonResult.abi, commonResult.protocol);
                displayDecoded(decoded);
            } catch (e) {
                const decoded = manualDecode(txData);
                displayManualDecoded(decoded);
            }
        } else {
            const decoded = manualDecode(txData);
            displayManualDecoded(decoded);
        }
    }
}

// Decode automatic mode
async function decodeAuto() {
    const apiKey = document.getElementById('api-key').value.trim();
    const contractAddress = document.getElementById('contract-address').value.trim();
    const txData = document.getElementById('auto-tx-data').value.trim();

    if (!txData) {
        showError('Please provide transaction data');
        return;
    }

    // Check if data is EIP-712 JSON structure (typed data)
    if (isEIP712JSON(txData)) {
        console.log('Auto mode: Processing as EIP-712 JSON');
        try {
            const decoded = await encodeAndDecodeEIP712JSON(txData);
            displayEIP712Decoded(decoded);
            return;
        } catch (error) {
            console.error('EIP-712 JSON processing error:', error);
            showError('Failed to process EIP-712 JSON: ' + error.message);
            return;
        }
    }

    // Check if data is EIP-712 encoded hex
    if (isEIP712Data(txData)) {
        console.log('Auto mode: Processing as EIP-712 Hex');
        try {
            const decoded = await decodeEIP712(txData);
            displayEIP712Decoded(decoded);
            return;
        } catch (error) {
            console.error('EIP-712 hex decode failed:', error);
            // Fall through to normal processing
        }
    }

    if (!contractAddress) {
        showError('Please provide contract address');
        return;
    }

    if (apiKey) {
        saveApiKey(apiKey);
    }

    try {
        const commonResult = tryCommonAbis(txData);
        if (commonResult) {
            const decoded = await decodeTxData(txData, commonResult.abi, commonResult.protocol, contractAddress);
            displayDecoded(decoded);
            return;
        }

        if (!apiKey) {
            showError('No matching common ABI found and no API key provided. Attempting manual decode...');
            const decoded = manualDecode(txData);
            displayManualDecoded(decoded);
            return;
        }

        const abi = await fetchAbiFromEtherscan(contractAddress, apiKey);
        const decoded = await decodeTxData(txData, abi, null, contractAddress);
        displayDecoded(decoded);
    } catch (error) {
        const chain = getCurrentChain();
        if (error.message === 'CONTRACT_NOT_VERIFIED') {
            showError(`❌ Contract Not Verified on Etherscan (${chain.name}) - Using best-effort Decoder`);
            const decoded = manualDecode(txData);
            displayManualDecoded(decoded);
        } else if (error.message === 'CORS_BLOCKED') {
            showError('🚫 Network Access Blocked - Using best-effort Decoder');
            const decoded = manualDecode(txData);
            displayManualDecoded(decoded);
        } else {
            showError('Failed to decode with ABI - Using best-effort Decoder');
            const decoded = manualDecode(txData);
            displayManualDecoded(decoded);
        }
    }
}

// Display decoded transaction with ABI
async function displayDecoded(decoded) {
    const chain = getCurrentChain();
    const riskLevel = assessRisk(decoded.functionName, decoded.args, decoded.protocol);
    
    let html = '';
    
    const riskLabels = {
        'low': '✓ Low Risk',
        'medium': '⚠ Medium Risk',
        'high': '⚠ High Risk'
    };
    
    // Determine if this is an approval transaction for better tooltip
    const isApproval = decoded.functionName.toLowerCase().includes('approve');
    const isUnlimitedApproval = isApproval && riskLevel === 'high';
    const isLimitedApproval = isApproval && riskLevel === 'medium';
    
    const riskTooltips = {
        'low': `<strong>Low Risk Transaction</strong>
                <ul>
                    <li>Read-only operations</li>
                    <li>Standard deposits</li>
                    <li>Non-sensitive function calls</li>
                </ul>
                <em>Generally safe to proceed</em>`,
        'medium': isLimitedApproval 
            ? `<strong>Medium Risk Transaction</strong>
               <ul>
                   <li>Grants LIMITED token approval</li>
                   <li>Spender can only use the approved amount</li>
                   <li>You can revoke this later</li>
               </ul>
               <em>Review the approved amount and spender address</em>`
            : `<strong>Medium Risk Transaction</strong>
               <ul>
                   <li>Transfers tokens from your wallet</li>
                   <li>Withdraws funds</li>
                   <li>Borrows against collateral</li>
               </ul>
               <em>Review amounts carefully</em>`,
        'high': isUnlimitedApproval
            ? `<strong>High Risk Transaction</strong>
               <ul>
                   <li>Grants UNLIMITED token approval</li>
                   <li>Spender can take all your tokens</li>
                   <li>Commonly used by DEXs for convenience</li>
                   <li>Can be revoked anytime</li>
               </ul>
               <em>⚠️ Only approve highly trusted contracts!</em>`
            : `<strong>High Risk Transaction</strong>
               <ul>
                   <li>Transfers contract ownership</li>
                   <li>Executes delegatecalls</li>
                   <li>Sets operator permissions (NFTs)</li>
               </ul>
               <em>⚠️ Only approve trusted contracts!</em>`
    };
    
    html += `<div class="risk-badge risk-${riskLevel}">
                ${riskLabels[riskLevel]}
                <span class="tooltip-container">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">${riskTooltips[riskLevel]}</span>
                </span>
             </div>`;
    html += `<span class="chain-badge">${chain.name}</span>`;

    if (decoded.protocol) {
        html += `<div class="info-row">
            <div class="info-label">Protocol Detected</div>
            <div class="info-value">${decoded.protocol}</div>
        </div>`;
    }

    html += `<div class="info-row">
        <div class="info-label">Function Name</div>
        <div class="info-value">${decoded.functionName}</div>
    </div>`;

    html += `<div class="info-row">
        <div class="info-label">Function Signature</div>
        <div class="info-value">${decoded.signature}</div>
    </div>`;

    // Special handling for Eisen Finance
    if (decoded.protocol === 'EisenFinance' && decoded.functionName === 'swap') {
        try {
            const swapDesc = decoded.args[0];

            html += `<div class="info-row">
                <div class="info-label">Eisen Finance Swap Details</div>
                <div class="param-group">`;

            // Source Amount
            const srcAmount = swapDesc.srcAmount;
            html += `<div class="param-item">
                <strong>Source Amount:</strong><br>
                <span style="color: #666;">${srcAmount.toString()}</span>`;

            if (swapDesc.path && swapDesc.path.length > 0) {
                const srcToken = getTokenInfo(swapDesc.path[0]);
                if (srcToken) {
                    const formatted = ethers.utils.formatUnits(srcAmount, srcToken.decimals);
                    const formattedWithCommas = formatWithCommas(formatted);
                    html += `<span class="formatted-value">${formattedWithCommas} ${srcToken.symbol}</span>`;
                }
            }
            html += `</div>`;

            // Min Return Amount
            const minReturn = swapDesc.minReturnAmount;
            html += `<div class="param-item">
                <strong>Minimum Return Amount:</strong><br>
                <span style="color: #666;">${minReturn.toString()}</span>`;

            if (swapDesc.path && swapDesc.path.length > 1) {
                const dstToken = getTokenInfo(swapDesc.path[swapDesc.path.length - 1]);
                if (dstToken) {
                    const formatted = ethers.utils.formatUnits(minReturn, dstToken.decimals);
                    const formattedWithCommas = formatWithCommas(formatted);
                    html += `<span class="formatted-value">${formattedWithCommas} ${dstToken.symbol}</span>`;
                }
            }
            html += `</div>`;

            // Guaranteed Amount
            const guaranteed = swapDesc.guaranteedAmount;
            html += `<div class="param-item">
                <strong>Guaranteed Amount:</strong><br>
                <span style="color: #666;">${guaranteed.toString()}</span>`;

            if (swapDesc.path && swapDesc.path.length > 1) {
                const dstToken = getTokenInfo(swapDesc.path[swapDesc.path.length - 1]);
                if (dstToken) {
                    const formatted = ethers.utils.formatUnits(guaranteed, dstToken.decimals);
                    const formattedWithCommas = formatWithCommas(formatted);
                    html += `<span class="formatted-value">${formattedWithCommas} ${dstToken.symbol}</span>`;
                }
            }
            html += `</div>`;

            // Receiver
            html += `<div class="param-item">
                <strong>Receiver:</strong> ${swapDesc.receiver}
            </div>`;

            // Swap Path
            if (swapDesc.path && swapDesc.path.length > 0) {
                html += `<div class="param-item">
                    <strong>Swap Path:</strong><br>`;
                swapDesc.path.forEach((addr, i) => {
                    const tokenInfo = getTokenInfo(addr);
                    const symbol = tokenInfo ? ` (${tokenInfo.symbol})` : '';
                    html += `<span style="font-size: 0.9em;">${i > 0 ? '→ ' : ''}${addr}${symbol}</span><br>`;
                });
                html += `</div>`;
            }

            // Distribution (shows how much goes to each DEX)
            if (swapDesc.distribution && swapDesc.distribution !== '0x') {
                html += `<div class="param-item">
                    <strong>DEX Distribution:</strong><br>
                    <span style="color: #666; font-size: 0.9em;">Multi-DEX routing via ${swapDesc.data.length} protocol(s)</span>
                </div>`;
            }

            html += `</div></div>`;
        } catch (e) {
            console.error('Error decoding Eisen Finance swap:', e);
        }
    }

    // Special handling for Uniswap Universal Router
    if (decoded.protocol === 'UniswapUniversalRouter' && decoded.functionName === 'execute') {
        try {
            const commandsBytes = decoded.args[0];
            const inputs = decoded.args[1];
            const commands = decodeUniversalRouterCommands(commandsBytes, inputs);

            html += `<div class="info-row">
                <div class="info-label">Uniswap Universal Router Commands</div>
                <div class="param-group">`;

            for (const cmd of commands) {
                html += `<div class="param-item">
                    <strong>Command ${cmd.index + 1}:</strong> ${cmd.name} <span style="color: #999;">(${cmd.code})</span><br>`;

                if (cmd.decoded && !cmd.decoded.error) {
                    html += `<div style="margin-top: 8px; padding-left: 10px; border-left: 2px solid #dc0d17;">`;

                    for (const [key, value] of Object.entries(cmd.decoded)) {
                        if (key === 'raw') continue;

                        let displayValue = value;
                        let tokenSymbol = null;

                        // Format token addresses
                        if ((key === 'token' || key === 'recipient') && value.startsWith && value.startsWith('0x')) {
                            const tokenInfo = getTokenInfo(value);
                            if (tokenInfo) {
                                tokenSymbol = tokenInfo.symbol;
                                displayValue = `${value} (${tokenSymbol})`;
                            }
                        }

                        // Format amounts with token info
                        if ((key.includes('amount') || key.includes('Amount')) && tokenSymbol) {
                            const tokenInfo = getTokenInfo(cmd.decoded.token);
                            if (tokenInfo) {
                                const formatted = ethers.utils.formatUnits(value, tokenInfo.decimals);
                                const formattedWithCommas = formatWithCommas(formatted);
                                displayValue = `${value} (${formattedWithCommas} ${tokenInfo.symbol})`;
                            }
                        } else if (key.includes('amount') || key.includes('Amount')) {
                            // Try to format as ETH if no token specified
                            try {
                                const bn = ethers.BigNumber.from(value);
                                if (bn.gt(0)) {
                                    const formatted = ethers.utils.formatEther(bn);
                                    const formattedWithCommas = formatWithCommas(formatted);
                                    displayValue = `${value} (~${formattedWithCommas} ETH)`;
                                }
                            } catch (e) {
                                // Keep original value
                            }
                        }

                        // Format paths (token swap routes)
                        if (key === 'path') {
                            if (Array.isArray(value)) {
                                html += `<span style="font-size: 0.9em;"><strong>${key}:</strong><br>`;
                                value.forEach((addr, i) => {
                                    const tokenInfo = getTokenInfo(addr);
                                    const symbol = tokenInfo ? ` (${tokenInfo.symbol})` : '';
                                    html += `&nbsp;&nbsp;${i > 0 ? '→ ' : ''}${addr}${symbol}<br>`;
                                });
                                html += `</span>`;
                                continue;
                            } else if (value.startsWith && value.startsWith('0x')) {
                                // Encoded path for V3
                                displayValue = `${value.slice(0, 20)}... (V3 encoded path)`;
                            }
                        }

                        // Format bips (basis points) to percentage
                        if (key === 'bips') {
                            const percentage = (parseInt(value) / 100).toFixed(2);
                            displayValue = `${value} (${percentage}%)`;
                        }

                        html += `<span style="font-size: 0.9em;"><strong>${key}:</strong> ${displayValue}</span><br>`;
                    }

                    html += `</div>`;
                } else if (cmd.decoded && cmd.decoded.error) {
                    html += `<span style="color: #999; font-size: 0.9em;">⚠️ Could not fully decode: ${cmd.decoded.error}</span><br>`;
                    html += `<span style="color: #666; font-size: 0.85em;">Raw: ${cmd.input.slice(0, 66)}...</span>`;
                } else if (cmd.input) {
                    html += `<span style="color: #666; font-size: 0.9em;">Input Data: ${cmd.input.slice(0, 66)}${cmd.input.length > 66 ? '...' : ''}</span>`;
                }

                html += `</div>`;
            }

            html += `</div></div>`;
        } catch (e) {
            console.error('Error decoding Universal Router commands:', e);
        }
    }

    html += `<div class="info-row">
        <div class="info-label">Parameters</div>
        <div class="param-group">`;

    let contextTokenAddress = decoded.contractAddress || null;

    for (let index = 0; index < decoded.fragment.inputs.length; index++) {
        const input = decoded.fragment.inputs[index];
        const value = decoded.args[index];
        let displayValue = value.toString();
        let formattedAmount = null;

        if (input.type === 'address') {
            displayValue = value;
        } else if (input.type.includes('uint') || input.type.includes('int')) {
            displayValue = ethers.BigNumber.isBigNumber(value)
                ? value.toString()
                : value.toString();

            if ((input.name.toLowerCase().includes('amount') ||
                 input.name.toLowerCase().includes('value') ||
                 input.name === '_value' ||
                 input.name === 'value' ||
                 input.name === 'amount') &&
                ethers.BigNumber.isBigNumber(value)) {

                let tokenAddress = null;
                for (let j = 0; j < decoded.fragment.inputs.length; j++) {
                    if (decoded.fragment.inputs[j].type === 'address' &&
                        (decoded.fragment.inputs[j].name.toLowerCase().includes('token') ||
                         decoded.fragment.inputs[j].name.toLowerCase().includes('asset'))) {
                        tokenAddress = decoded.args[j];
                        break;
                    }
                }

                if (!tokenAddress && contextTokenAddress) {
                    tokenAddress = contextTokenAddress;
                }

                if (tokenAddress) {
                    formattedAmount = await formatTokenAmount(value, tokenAddress);
                }
            }
        } else if (input.type.includes('[]')) {
            displayValue = Array.isArray(value) ? value.join(', ') : value.toString();
        } else if (input.type === 'bytes') {
            // Show abbreviated bytes for readability
            displayValue = value.slice(0, 66) + (value.length > 66 ? '...' : '');
        }

        html += `<div class="param-item">
            <strong>${input.name || `param${index}`}</strong> (${input.type})<br>
            <span style="color: #666;">${displayValue}</span>`;

        if (formattedAmount) {
            html += `<span class="formatted-value">≈ ${formattedAmount}</span>`;
        }

        html += `</div>`;
    }

    html += `</div></div>`;

    // Add transaction data hash
    if (decoded.txData) {
        const txHash = ethers.utils.keccak256(decoded.txData);
        html += `<div class="info-row">
            <div class="info-label">Transaction Data Hash</div>
            <div class="info-value" style="word-break: break-all;">${txHash}</div>
            <div class="small-text" style="margin-top: 10px;">Compare this hash with your hardware wallet before signing</div>
        </div>`;
    }

    const jsonOutput = {
        chain: chain.name,
        function: decoded.functionName,
        signature: decoded.signature,
        parameters: {}
    };

    decoded.fragment.inputs.forEach((input, index) => {
        jsonOutput.parameters[input.name || `param${index}`] = {
            type: input.type,
            value: decoded.args[index].toString()
        };
    });

    html += `<div class="info-row">
        <div class="info-label">JSON Output</div>
        <div class="info-value"><pre>${JSON.stringify(jsonOutput, null, 2)}</pre></div>
    </div>`;

    document.getElementById('output-content').innerHTML = html;
    showOutput();
}


// Display EIP-712 decoded message
function displayEIP712Decoded(decoded) {
    const chain = getCurrentChain();

    const eip712Tooltip = `<strong>EIP-712 Typed Message</strong>
                           <ul>
                               <li>Structured data for signing</li>
                               <li>Used by dApps for off-chain signatures</li>
                               <li>Common in DEX orders, permits, meta-transactions</li>
                               <li>Shows ABI-encoded representation</li>
                           </ul>
                           <em>Verify all fields before signing</em>`;

    let html = `<div class="risk-badge risk-medium">
                    📝 EIP-712 Typed Message Detected
                    <span class="tooltip-container">
                        <span class="tooltip-icon">?</span>
                        <span class="tooltip-text">${eip712Tooltip}</span>
                    </span>
                </div>`;
    html += `<span class="chain-badge">${chain.name}</span>`;

    // Display domain and primary type if available (from JSON)
    if (decoded.isFromJSON && decoded.domain) {
        html += `<div class="info-row">
            <div class="info-label">Message Type</div>
            <div class="info-value">
                <strong>Primary Type:</strong> ${decoded.primaryType}<br>
                <strong>Domain:</strong> ${decoded.domain.name || 'N/A'}<br>
                <strong>Chain ID:</strong> ${decoded.domain.chainId || 'N/A'}<br>
                <strong>Verifying Contract:</strong> ${decoded.domain.verifyingContract || 'N/A'}
            </div>
        </div>`;
    }

    // Step 1: Type Hash
    if (decoded.typeHash || decoded.potentialTypeHash) {
        html += `<div class="info-row">
            <div class="info-label">
                <span class="step-badge">STEP 1</span> Type Hash
            </div>
            <div class="info-value" style="word-break: break-all;">${decoded.typeHash || decoded.potentialTypeHash}</div>
            <div class="small-text" style="margin-top: 10px;">keccak256 of the type definition string</div>
        </div>`;
    }

    // Step 2: ABI-Encoded Message Data (RAW HEX)
    html += `<div class="info-row">
        <div class="info-label">
            <span class="step-badge">STEP 2</span> ABI-Encoded Message Data (RAW HEX)
        </div>
        <div class="info-value" style="word-break: break-all;">${decoded.rawData}</div>
        <div class="small-text" style="margin-top: 10px;">This is the ABI-encoded representation of the typed message</div>
    </div>`;

    // Step 3: Message Hash (Struct Hash)
    if (decoded.structHash) {
        html += `<div class="info-row">
            <div class="info-label">
                <span class="step-badge">STEP 3</span> Message Hash (Struct Hash)
            </div>
            <div class="info-value" style="word-break: break-all;">${decoded.structHash}</div>
            <div class="small-text" style="margin-top: 10px;">keccak256(typeHash + encodedMessage)</div>
        </div>`;
    }

    // Step 4: Domain Separator (if available)
    if (decoded.domainSeparator) {
        html += `<div class="info-row">
            <div class="info-label">
                <span class="step-badge">STEP 4</span> Domain Separator
            </div>
            <div class="info-value" style="word-break: break-all;">${decoded.domainSeparator}</div>
            <div class="small-text" style="margin-top: 10px;">Hash of the domain (chain, contract, etc.)</div>
        </div>`;
    }

    // Final: EIP-712 Signature Hash (if available)
    if (decoded.finalHash) {
        html += `<div class="info-row" style="border: 2px solid #28a745;">
            <div class="info-label">
                <span class="step-badge" style="background: #28a745;">FINAL</span> EIP-712 Signature Hash
            </div>
            <div class="info-value" style="word-break: break-all;">${decoded.finalHash}</div>
            <div class="small-text" style="margin-top: 10px;">keccak256("\\x19\\x01" + domainSeparator + structHash) - This is what gets signed</div>
        </div>`;
    } else {
        // Note about missing information
        html += `<div class="info-row">
            <div class="info-label">⚠️ Missing Information</div>
            <div class="info-value" style="color: #856404;">
                ${decoded.note || 'This is ABI-encoded typed message data.'}<br><br>
                <strong>To compute the complete EIP-712 signature hash, the following are needed:</strong><br>
                • Domain Separator (requires domain configuration: chain ID, verifying contract)<br>
                • EIP-712 Signature Hash (requires: keccak256("\\x19\\x01" + domainSeparator + structHash))<br><br>
                Paste the original typed data JSON structure to see the complete signature hash.
            </div>
        </div>`;
    }

    // Display interpreted parameters
    if (decoded.interpretations && decoded.interpretations.length > 0) {
        html += `<div class="info-row">
            <div class="info-label">Decoded Parameters</div>
            <div class="param-group">`;

        decoded.interpretations.forEach((param, index) => {
            html += `<div class="param-item">
                <strong>Parameter ${index}</strong><br>
                <span style="color: #666; font-size: 0.85em;">Raw: ${param.raw}</span><br><br>`;

            param.possibleTypes.forEach(type => {
                if (type.type === 'address') {
                    html += `<span style="color: #dc0d17;">📍 Address:</span> ${type.value}<br>`;
                } else if (type.type === 'uint256') {
                    html += `<span style="color: #666;">🔢 Uint256:</span> ${type.value}<br>`;
                } else if (type.type === 'bytes32') {
                    html += `<span style="color: #666;">📦 Bytes32/Hash:</span> ${type.value.slice(0, 20)}...<br>`;
                }
            });

            html += `</div>`;
        });

        html += `</div></div>`;
    }

    // Add transaction data hash
    if (decoded.rawData) {
        const txHash = ethers.utils.keccak256(decoded.rawData);
        html += `<div class="info-row">
            <div class="info-label">Transaction Data Hash</div>
            <div class="info-value" style="word-break: break-all;">${txHash}</div>
            <div class="small-text" style="margin-top: 10px;">Compare this hash with your hardware wallet before signing</div>
        </div>`;
    }

    document.getElementById('output-content').innerHTML = html;
    showOutput();
}

// Display manual decoded transaction
function displayManualDecoded(decoded) {
    const chain = getCurrentChain();
    const assessment = assessTransaction(decoded);

    let html = '';

    // Show proxy warning if present
    if (decoded.proxyWarning) {
        html += `<div class="error-message" style="margin-bottom: 20px;">
                    ${decoded.proxyWarning}
                 </div>`;
    }

    const aiTooltip = `<strong>Best-effort heuristic Decoding</strong>
                       <ul>
                           <li>No contract ABI available</li>
                           <li>Parameter names are educated guesses</li>
                           <li>Types inferred from data patterns</li>
                           <li>May not be 100% accurate</li>
                       </ul>
                       <em>For precise decoding, provide the ABI</em>`;

    html += `<div class="risk-badge risk-medium">
                    ⚠ Best-effort heuristic Decode (No ABI)
                    <span class="tooltip-container">
                        <span class="tooltip-icon">?</span>
                        <span class="tooltip-text">${aiTooltip}</span>
                    </span>
                </div>`;
    html += `<span class="chain-badge">${chain.name}</span>`;

    html += `<div class="info-row">
        <div class="info-label">Best-effort Assessment</div>
        <div class="info-value">
            <strong style="color: #dc0d17;">Likely Function:</strong> ${assessment.likelyFunction}<br>
            <strong>Confidence:</strong> ${assessment.confidence}<br><br>
            <strong>Description:</strong><br>
            ${assessment.description}
        </div>
    </div>`;

    html += `<div class="info-row">
        <div class="info-label">Function Selector</div>
        <div class="info-value">${decoded.selector}</div>
    </div>`;

    if (assessment.parameters.length > 0) {
        html += `<div class="info-row">
            <div class="info-label">Interpreted Parameters</div>
            <div class="param-group">`;

        assessment.parameters.forEach((param) => {
            html += `<div class="param-item">
                <strong>${param.name}</strong> (${param.type})<br>
                <span style="color: #666; font-size: 0.9em;">${param.description}</span><br>`;

            if (param.formatted) {
                html += `<span class="formatted-value">${param.formatted}</span><br>`;
            }

            html += `<span style="color: #999; font-size: 0.85em;">Raw: ${param.value}</span>
            </div>`;
        });

        html += `</div></div>`;
    }

    // Add transaction data hash for manual decode too
    if (decoded.txData) {
        const txHash = ethers.utils.keccak256(decoded.txData);
        html += `<div class="info-row">
            <div class="info-label">Transaction Data Hash</div>
            <div class="info-value" style="word-break: break-all;">${txHash}</div>
            <div class="small-text" style="margin-top: 10px;">Compare this hash with your hardware wallet before signing</div>
        </div>`;
    }

    html += `<div class="info-row">
        <div class="info-label">All Possible Interpretations</div>
        <div class="param-group">`;

    decoded.interpretations.forEach((param, index) => {
        html += `<div class="param-item">
            <strong>Parameter ${index}</strong><br>
            <span style="color: #666; font-size: 0.85em;">Raw: ${param.raw}</span><br><br>`;

        param.possibleTypes.forEach(type => {
            if (type.type === 'address') {
                html += `<span style="color: #dc0d17;">📍 Address:</span> ${type.value}<br>`;
            } else if (type.type === 'token_address') {
                html += `<span style="color: #dc0d17;">🪙 Token Address:</span> ${type.value}<br>`;
                html += `<span class="formatted-value">${type.symbol} (${type.decimals} decimals)</span><br>`;
            } else if (type.type === 'uint256') {
                html += `<span style="color: #666;">🔢 Uint256:</span> ${type.value}<br>`;
            } else if (type.type.startsWith('amount_')) {
                const decimals = type.type.match(/\d+/)[0];
                html += `<span style="color: #28a745;">💰 Amount (${decimals} decimals):</span> ${type.value}<br>`;
            } else if (type.type === 'bytes32') {
                html += `<span style="color: #666;">📦 Bytes32:</span> ${type.value.slice(0, 20)}...<br>`;
            }
        });

        html += `</div>`;
    });

    html += `</div></div>`;

    html += `<div class="info-row">
        <div class="info-label">⚠️ Important Note</div>
        <div class="info-value" style="color: #856404;">
            This is a best-effort interpretation without the contract ABI.
            Parameter names and exact types may be incorrect.
            For accurate decoding, provide the contract ABI in Manual Mode or verify the contract on Etherscan.
        </div>
    </div>`;

    document.getElementById('output-content').innerHTML = html;
    showOutput();
}

// Initialize on page load
window.onload = function() {
    loadApiKey();
    updateExplorerHint();
};
